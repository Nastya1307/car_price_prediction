import json
import os
from datetime import datetime
import dill
import pandas as pd

path = os.environ.get('$PROJECT_PATH', '/home/airflow/airflow_hw')
#path = os.environ.get('~/airflow_hw', 'airflow_hw')
def predict():
    model_filename = sorted(os.listdir(f'{path}/data/models'))
    with open(f'{path}/data/models/{model_filename[-1]}', 'rb') as file:
        model = dill.load(file)

    df_pred = pd.DataFrame(columns=['car_id', 'pred'])
    files_list = os.listdir(f'{path}/data/test')

    for filename in files_list:
        with open(f'{path}/data/test/{filename}') as f:
            form = json.load(f)
        df = pd.DataFrame.from_dict([form])
        prediction = model.predict(df)
        dict_pred = {'car_id': df.id, 'pred': prediction}
        data = pd.DataFrame(dict_pred)
        df_pred = pd.concat([df_pred, data], axis=0)

    df_pred.to_csv(f'{path}/data/predictions/pred{datetime.now().strftime("%Y%m%d%H%M")}.csv', index=False)




if __name__ == '__main__':
    predict()
